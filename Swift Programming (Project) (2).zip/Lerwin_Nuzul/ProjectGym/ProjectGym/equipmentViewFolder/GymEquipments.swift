//
//  GymEquipments.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 15/4/21.
//

import UIKit

class GymEquipments: NSObject {
    var equipmentID = ""
    var equipmentName = ""
    var equipmentImage = ""
    var equipmentDesc = ""
    var equipmentMuscleDesc = ""
    
    init(_ equipmentID: String, _ equipmentName: String,_ equipmentImage: String, _ equipmentDesc: String,_ equipmentMuscleDesc: String) {
        self.equipmentID = equipmentID
        self.equipmentName = equipmentName
        self.equipmentImage = equipmentImage
        self.equipmentDesc = equipmentDesc
        self.equipmentMuscleDesc = equipmentMuscleDesc
        
    }
    
}
