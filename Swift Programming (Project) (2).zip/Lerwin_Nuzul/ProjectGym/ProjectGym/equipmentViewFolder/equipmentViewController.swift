//
//  ViewController.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 14/4/21.
//

import UIKit

class equipmentViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    
    @IBOutlet weak var tableView: UITableView!
    

    var gymEquipmentsList: [GymEquipments] = []
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(gymEquipmentsList.count)

        return gymEquipmentsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "equipmentCell", for: indexPath) as! CustomCellTableViewCell
        
        

        cell.equipmentNameView?.text = gymEquipmentsList[indexPath.row].equipmentName
        cell.equipmentImageView?.image = UIImage(named: gymEquipmentsList[indexPath.row].equipmentImage)
        
        
        return cell
        
    }
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
           tableView.dataSource = self
        
        gymEquipmentsList.append(GymEquipments("1a", "Treadmill", "treadmill", "The treadmill is a great way to practice walking or running at any pace one is comportable with.", "It targets primarily your lungs in regards to developing your general fitness, but it can also be used to provide great core and leg workout."))
        gymEquipmentsList.append(GymEquipments("1b", "Rowing machine", "rowing", "Rowing machines are a great way to work the entire body by replicating outdoor rowing", "As it’s a cardio machine you’re going to work the lungs and improve your fitness – in conjunction with this expect to get a great leg and arm workout."))
        gymEquipmentsList.append(GymEquipments("1c", "Elliptical machine", "elliptical", "The elliptical machine is a great way to simulate a running motion that places no impact on the knee joints.", "Elliptical machines are very versatile in that they can be used purely for cardio purposes (fitness)."))
        gymEquipmentsList.append(GymEquipments("1d", "Leg press machine", "legPress", "they are designed to safely and effectively work every muscle in the lower body while protecting the joints.", "Leg presses target every muscle in the lower body including the thighs, the hamstrings, the glutes and the calves."))
        gymEquipmentsList.append(GymEquipments("1e", "Leg extension machine", "legExtension", "A leg extension machine will allow you to isolate the quads on their own and either strengthen them or tone them", "Leg extension machines work the quadriceps muscle."))
        gymEquipmentsList.append(GymEquipments("1f", "Cable crossover machine", "crossover",  "Cable crossover machines are one of the most versatile pieces of gym equipment available.", "This is completely dependent on the exercise – you can use the crossover to perform almost any exercise you can think of."))
        
        //tableView.reloadData()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "ShowEquipmentDetail"){
            
            let detailViewController = segue.destination as! equipmentDetailViewController
            let myIndexPath = self.tableView.indexPathForSelectedRow
            print(myIndexPath) // get the index of the row

            if (myIndexPath != nil){
                let equipment = gymEquipmentsList[myIndexPath!.row]
                detailViewController.equipmentItem = equipment
            }
        }
        
    }


}

