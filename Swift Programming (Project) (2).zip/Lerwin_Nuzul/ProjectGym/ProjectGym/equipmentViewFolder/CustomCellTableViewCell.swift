//
//  CustomCellTableViewCell.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 15/4/21.
//

import UIKit

class CustomCellTableViewCell: UITableViewCell {

    @IBOutlet weak var equipmentImageView: UIImageView!
    @IBOutlet weak var equipmentNameView: UILabel!
    @IBOutlet weak var readMoreView: UILabel!

    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
