//
//  equipmentDetailViewController.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 15/4/21.
//

import UIKit

class equipmentDetailViewController: UIViewController {

    @IBOutlet weak var equipmentImageView: UIImageView!
    
    @IBOutlet weak var equipmentNameView: UILabel!
    @IBOutlet weak var equipmentDescView: UILabel!
    @IBOutlet weak var equipmentMuscleView: UILabel!
    @IBOutlet weak var muscleImageView: UIImageView!
    
    
    var equipmentItem: GymEquipments?
    
    override func viewWillAppear(_ animated:Bool) {
        super.viewWillAppear(animated)

        equipmentImageView.image  = UIImage(named: (equipmentItem?.equipmentImage)!)
        equipmentNameView.text = equipmentItem?.equipmentName
        equipmentDescView.text = equipmentItem?.equipmentDesc
        equipmentMuscleView.text = equipmentItem?.equipmentMuscleDesc
        
        self.navigationItem.title = equipmentItem?.equipmentName
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        muscleImageView.image = UIImage(named: "muscle")
    }
    



   

}
