//
//  planObject.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 1/5/21.
//

import UIKit

class planObject: NSObject {
    var userID : String
    var name: String
    var checked: Int
    var uniqueID: String
    init(userID: String, name: String, checked: Int, uniqueID: String)
    {
        self.userID = userID
        self.name = name
        self.checked = checked
        self.uniqueID = uniqueID
    }
}
