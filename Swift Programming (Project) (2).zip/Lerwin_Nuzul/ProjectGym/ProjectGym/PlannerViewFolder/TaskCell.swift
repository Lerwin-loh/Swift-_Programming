//
//  TaskCell.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 1/5/21.
//

import UIKit

protocol ChangeButton {
    func changeButton(checked: Int, index: Int?, uniqueID: String, name: String)
}
class TaskCell: UITableViewCell {
    @IBOutlet weak var taskNameLabel: UILabel!

    @IBOutlet weak var checkBoxOutlet: UIButton!
    
    var user_id: String?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //retrieving userID from NSUserdefaults
        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func checkBoxAction(_ sender: Any) {
        if tasks![indexP!].checked == 1 { //if its checked, when the user clicks it we will uncheck it
            delegate?.changeButton(checked: 0, index: indexP, uniqueID: uniqueID!, name: taskNameLabel.text! )
            
        }else{
            delegate?.changeButton(checked: 1, index: indexP, uniqueID: uniqueID!, name: taskNameLabel.text! )

        }
    }
    
    
    var delegate: ChangeButton?
    var indexP: Int?
    var uniqueID: String?
    var tasks: [planObject]?
}
