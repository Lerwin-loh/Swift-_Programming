//
//  AddTaskViewController.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 1/5/21.
//

import UIKit
// sending data back to our previous scene
protocol AddTask{
    func addTask(userID:String, name: String, checked: Int, uniqueID: String)
}

class AddTaskViewController: UIViewController {
    var user_id: String?
    var delegate: AddTask?
    @IBOutlet weak var quote2: UILabel!
  
    @IBAction func addAction(_ sender: Any) {
        if taskNameOutlet.text != "" {
            //whenever a user adds a task default will always be unchecked lol
            delegate?.addTask(userID: user_id!, name: taskNameOutlet.text!, checked: 0, uniqueID: UUID().uuidString)
            navigationController?.popViewController(animated: true)
        }
    }
    @IBOutlet weak var taskNameOutlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        //retrieving userID from NSUserdefaults
        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")
        
        quote2.text = "DO IT NOW \n Sometimes 'LATER' becomes 'NEVER' ";
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
