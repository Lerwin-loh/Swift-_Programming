//
//  plannerViewController.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 1/5/21.
//

import UIKit

class plannerViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddTask, ChangeButton{
    func addTask(userID: String, name: String, checked: Int, uniqueID: String) {
        let object = planObject(userID: userID, name: name, checked: checked, uniqueID: uniqueID)
        tasks.append(object)
        PlannerDataManager.insertOrReplacePlan(plan: object)
        tableView.reloadData()
    }
    
    var tasks: [planObject] = []
    var user_id: String?
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //retrieving userID from NSUserdefaults
        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")
        
        PlannerDataManager.CreateDatabase()
        tasks = PlannerDataManager.loadData(userID: user_id!)
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath) as! TaskCell
        print(cell)
        let eachtask = tasks[indexPath.row]
        cell.taskNameLabel.text =  eachtask.name
        if eachtask.checked == 1 {
            cell.checkBoxOutlet.setImage( UIImage(named: "checkBoxFILLED") , for: .normal)
            
        } else{
            print("unchecking it")
            cell.checkBoxOutlet.setImage( UIImage(named: "checkBoxOUTLINE"), for: .normal)
            print("changed to outline")
        }
        
        
        cell.delegate = self //sending the functions to taskcell.swift
        cell.indexP = indexPath.row
        cell.tasks = tasks
        cell.uniqueID = eachtask.uniqueID
        print(cell.uniqueID)
        print("returning cell")
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete
        {
            let object = tasks[indexPath.row]
            PlannerDataManager.deleteAPlan(plan: object)
            tasks = PlannerDataManager.loadData(userID: user_id! )
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AddTaskViewController
        vc.delegate = self
    }
    
    func changeButton(checked: Int, index: Int?, uniqueID: String, name: String) {
        tasks[index!].checked = checked
        print("this is the plan's uniqueID")
        print(uniqueID)
        let object = planObject(userID: user_id!, name: name, checked: checked, uniqueID: uniqueID)
        PlannerDataManager.replacePlan(plan: object)
        tableView.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

class Task {
    var name = ""
    var checked = false
    
    init(name: String) {
        self.name = name
    }
}
