//
//  HomeViewController.swift
//  ProjectGym
//
//  Created by Lerwin Loh on 24/4/21.
//

import UIKit
import UserNotifications

class HomeViewController: UIViewController {

    
    var user_id  : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        let user_ID = UserDefaults.standard.string(forKey: "userID")

        let bookingList = DataManagerBooking.loadBookings(user_ID!)
        
        let center = UNUserNotificationCenter.current()
        
        center.requestAuthorization(options: [.alert, .sound]){ (granted, error) in
            if error == nil{
                print("User permission is granded: \(granted)")
            }
        }
        
        let content = UNMutableNotificationContent()
        content.title = "Hey, i'm a notification"
        content.body = "Look at me!"
        
        let date = Date().addingTimeInterval(10)
        
        let dateComponent = Calendar.current.dateComponents([.year, .month, .day], from: date)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponent, repeats: false)
        
        
        let uuidString = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
        
        center.add(request){ (error) in
            // Check error parameter and handle this error
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
