//
//  HomeViewController.h
//  ProjectGym
//
//  Created by Lerwin Loh on 24/4/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
