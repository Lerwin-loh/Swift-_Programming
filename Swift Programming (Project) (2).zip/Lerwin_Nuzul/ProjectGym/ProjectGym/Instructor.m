//
//  Instructor.m
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

#import "Instructor.h"

@implementation Instructor

@end
