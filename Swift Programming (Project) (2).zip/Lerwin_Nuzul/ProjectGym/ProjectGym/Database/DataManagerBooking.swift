//
//  DataManagerBooking.swift
//  ProjectGym
//
//  Created by Training on 23/4/21.
//

import UIKit

class DataManagerBooking: NSObject {
    
    static func createDatabase(){
        SQLiteDB.sharedInstance.execute(sql:
                "CREATE TABLE IF NOT EXISTS " +
                "Bookings ( " +
                "   bookingID text primary key, " +
                "   userID text, " +
                "   instructorName text, " +
                "   date text, " +
                "   timeslot text, " +
                "   equipment text, " +
                "   addComments text " +
                ")"
            )
    }
    
    //load the list of movies from the database and convert into a [Movie] array
    static func loadBookings(_ user_id: String) -> [BookingSession]{
        let bookingRows = SQLiteDB.sharedInstance.query(sql:
                "SELECT userID, bookingID, instructorName, date, timeslot, equipment, addComments " +
                "FROM Bookings " +
                "WHERE userID = ? ", parameters: [user_id]
            )
        
        var bookings: [BookingSession] = []
        for row in bookingRows{
            bookings.append(
                BookingSession(row["userID"] as! String, row["bookingID"] as! String, row["instructorName"] as! String, row["date"] as! String, row["timeslot"] as! String, row["equipment"] as! String, row["addComments"] as! String)
                
            )
        }
        return bookings
    }
    
    //Insert a new movie record, and replace an existing path
    static func insertOrReplaceBooking(booking: BookingSession){
        SQLiteDB.sharedInstance.execute(sql:
            "INSERT OR REPLACE INTO Bookings ( userID, bookingID, instructorName, date, timeslot, equipment, addComments) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            parameters: [
                booking.userID,
                booking.bookingID,
                booking.instructorName,
                booking.date,
                booking.timeslot,
                booking.equipmentName,
                booking.addComments
            ]
        )
    }
    
    //Delete an existing booking record using the booking object's bookingID
    static func deleteBooking (booking: BookingSession){
        SQLiteDB.sharedInstance.execute(sql:
            "DELETE FROM Bookings WHERE bookingID = ? ",
                                        parameters: [booking.bookingID]
            )
    }
    
}
