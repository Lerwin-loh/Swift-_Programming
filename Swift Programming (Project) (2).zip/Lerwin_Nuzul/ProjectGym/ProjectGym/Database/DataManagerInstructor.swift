//
//  DataManagerInstructor.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

import UIKit


class DataManagerInstructor: NSObject {
    
    //Creating a Database table if not already created
    static func createDatabase(){
        SQLiteDB.sharedInstance.execute(sql:
                "CREATE TABLE IF NOT EXISTS " +
                "Instructors ( " +
                "   instructorID text primary key, " +
                "   instructorName text, " +
                "   instructorDescription text, " +
                "   instructorImage text" +
                ")"
            )
    }
    
    //load the list of instructors from the database and convert into a [instructor] array
    static func loadInstructors() -> [Instructor]{
        let instructorRows = SQLiteDB.sharedInstance.query(sql:
                "SELECT instructorID, instructorName, instructorDescription, instructorImage " +
                "FROM Instructors "
            )
        
        var instructors: [Instructor] = []
        for row in instructorRows{
            instructors.append(
                Instructor(row["instructorID"] as! String,
                           row["instructorName"] as! String,
                           row["instructorDescription"] as! String,
                           row["instructorImage"] as! String)
            )
        }
        return instructors
    }
    
    //Insert a new instructor record, and replace an existing path
    static func insertOrReplaceInstructor(instructor: Instructor){
        SQLiteDB.sharedInstance.execute(sql:
            "INSERT OR REPLACE INTO Instructors ( instructorID, instructorName, instructorDescription, instructorImage) " +
            "VALUES (?, ?, ?, ?)",
            parameters: [
                instructor.instructorID,
                instructor.instructorName,
                instructor.instructorDesc,
                instructor.instructorImage
            ]
        )
    }
    
    
    

}
