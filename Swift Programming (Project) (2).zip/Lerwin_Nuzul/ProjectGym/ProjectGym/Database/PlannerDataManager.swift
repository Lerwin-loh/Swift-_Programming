//
//  PlannerDataManager.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 1/5/21.
//

import UIKit

class PlannerDataManager: NSObject {
    
    static func CreateDatabase()
    { // we cant do bool because swift bool is true and false, and sql's bool is int
        SQLiteDB.sharedInstance.execute(sql:
            "CREATE TABLE IF NOT EXISTS " +
            "Planner( " +
            "   uniqueID text primary key,  " +
            "   name text, " +
            "   checked int,  " +
            "   userID text  " +
            " ) "
            )
    }
    
    static func loadData(userID: String) -> [planObject]{
        let data = SQLiteDB.sharedInstance.query(sql:
            " SELECT  userID, name, checked, uniqueID  " +
            " FROM Planner " +
            " WHERE userID = ? ", parameters: [userID]
            )
        var planList : [planObject] = []
        for row in data
        {
//            print(row)
            planList.append(
                planObject(userID: row["userID"] as! String, name: row["name"] as! String, checked: row["checked"] as! Int, uniqueID: row["uniqueID"] as! String
                )
            )
        }
        return planList
    }
    
    static func insertOrReplacePlan(plan: planObject )
    {
        print("inserting plan to db")
        SQLiteDB.sharedInstance.execute(sql:
           " INSERT INTO Planner ( uniqueID, " +
                                            "  name, checked, userID) " + " VALUES(?, ?, ?, ?) ", parameters: [plan.uniqueID, plan.name, plan.checked, plan.userID
                                            
                                            ])
        print("Sucessfully inserted")
    }
    
    static func replacePlan(plan:planObject) {
        print("inserting plan to db")
        SQLiteDB.sharedInstance.execute(sql:
       " REPLACE INTO Planner ( uniqueID, " +
                                        "  name, checked, userID) " + " VALUES(?, ?, ?, ?) ", parameters: [plan.uniqueID, plan.name, plan.checked, plan.userID])
    
    }
    static func deleteAllPlan(plan: planObject)
    {
        SQLiteDB.sharedInstance.execute(sql:
            "DELETE FROM Planner WHERE userID = ? ",
                                            parameters: [plan.userID]
            )
    }
    
    static func deleteAPlan(plan: planObject)
    {
        
        //this might delete duplicates with the same names, so we need to add unique id to each plan but im too lazy so eh
        SQLiteDB.sharedInstance.execute(sql:
            "DELETE FROM Planner WHERE userID = ? AND uniqueID = ? ",
                                        parameters: [plan.userID, plan.uniqueID]
            )
    }
}
