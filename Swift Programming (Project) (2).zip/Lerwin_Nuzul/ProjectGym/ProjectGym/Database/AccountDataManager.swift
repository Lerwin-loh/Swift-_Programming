//
//  AccountDataManager.swift
//  GymAppWithSql
//
//  Created by Nuzul FIrdaly on 16/4/21.
//

import UIKit

class AccountDataManager: NSObject {
    static func CreateDatabase()
    {
        SQLiteDB.sharedInstance.execute(sql:
            "CREATE TABLE IF NOT EXISTS " +
            "User( " +
            "   userID text primary key,  " +
            "   email text, " +
            "   password text,  " +
            "   firstName text,  " +
            "   lastName text, " +
            "   bio text, " +
            "   profilePicture text " +
            " ) "
            )
    }
    
    static func loadAccounts() -> [Account]{
        let accountRows = SQLiteDB.sharedInstance.query(sql:
            " SELECT  userID, email, password, firstName, lastName, bio, profilePicture" +
            " FROM User "
            )
        var account : [Account] = []
        for row in accountRows
        {
//            print(row)
            account.append(
                Account(
                    userID: row["userID"] as! String ,
                    email:
                        row["email"] as! String,
                    password:
                        row["password"] as! String,
                    firstName: row["firstName"] as! String,
                    lastName: row["lastName"] as! String,
                    bio: row["bio"] as! String? ?? "nothing" ,
                    profilePicture: row["profilePicture"] as! String? ?? "nothing"
                    
                )
            )
        }
        return account
    }
    
    static func insertOrReplaceAccount(account: Account )
    {
        SQLiteDB.sharedInstance.execute(sql:
           " INSERT OR REPLACE INTO User ( userID, " +
                                            "  email, password, firstName, lastName, bio, profilePicture) " + " VALUES(?, ?, ?, ?, ?, ?, ?) ", parameters: [account.userID, account.email, account.password, account.firstName, account.lastName, account.bio,    account.profilePicture])
    }
    static func deleteAccount(account: Account)
    {
        SQLiteDB.sharedInstance.execute(sql:
            "DELETE FROM User WHERE userID =? ",
                                            parameters: [account.userID]
            )
    }
}
