//
//  BridgingHeader.h
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BridgingHeader : NSObject

@end

NS_ASSUME_NONNULL_END
