//
//  Booking.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

import Cocoa

class Booking: UIViewController {

}
