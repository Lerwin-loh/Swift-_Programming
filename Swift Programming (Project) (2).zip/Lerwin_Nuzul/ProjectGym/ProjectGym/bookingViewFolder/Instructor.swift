//
//  Instructor.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//


import UIKit

class Instructor: NSObject {
    var instructorID: String
    var instructorName: String
    var instructorDesc: String
    var instructorImage: String
    
    init(_ instructorID: String, _ instructorName: String, _ instructorDesc: String, _ instructorImage: String) {
        self.instructorID = instructorID
        self.instructorName = instructorName
        self.instructorDesc = instructorDesc
        self.instructorImage = instructorImage
    }
    
    

}
