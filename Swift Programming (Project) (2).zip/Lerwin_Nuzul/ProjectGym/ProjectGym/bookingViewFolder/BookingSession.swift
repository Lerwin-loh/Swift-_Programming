//
//  BookingSession.swift
//  ProjectGym
//
//  Created by Training on 23/4/21.
//

import UIKit

class BookingSession: NSObject {
    var userID: String
    var bookingID: String
    var instructorName: String
    var date: String
    var timeslot: String
    var equipmentName: String
    var addComments: String
    
    init(_ userId: String, _ bookingID: String, _ instructorName: String, _ date: String,  _ timeslot: String, _ equipmentName: String, _ addComments: String) {
        self.instructorName = instructorName
        self.date = date
        self.timeslot = timeslot
        self.equipmentName = equipmentName
        self.addComments = addComments
        self.bookingID = bookingID
        self.userID = userId
    }
    
}
