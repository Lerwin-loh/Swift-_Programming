//
//  viewBookingTableViewCell.swift
//  ProjectGym
//
//  Created by Training on 23/4/21.
//

import UIKit

class viewBookingTableViewCell: UITableViewCell {

    @IBOutlet weak var dateView: UILabel!
    @IBOutlet weak var timeslotView: UILabel!
    @IBOutlet weak var instructorNameView: UILabel!
    @IBOutlet weak var equipmentNameView: UILabel!
    @IBOutlet weak var addCommentsView: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
