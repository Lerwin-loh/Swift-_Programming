//
//  BookingDetailViewController.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 17/4/21.
//

import UIKit

class BookingDetailViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var instructorImageView: UIImageView!
    @IBOutlet weak var instructorNameView: UILabel!
    @IBOutlet weak var insctructorDescView: UILabel!
    var instructorItem: Instructor?
    var bookingItem: BookingSession?
    
    @IBOutlet weak var addCommentsView: UITextField!
    
    @IBOutlet weak var DateView: UITextField!

    let datePicker = UIDatePicker()
    
    func createToolBar() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated:true)
        
        return toolbar
    }
    
    func createDatePicker(){
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.datePickerMode = .date
        datePicker.minimumDate = Date()
        DateView.inputView = datePicker
        DateView.inputAccessoryView = createToolBar()
    }
    
    @objc func donePressed(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        self.DateView.text = dateFormatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    
    @IBOutlet weak var timeslotView: UITextField!
    @IBOutlet weak var equipmentView: UITextField!
    

    let timeslotList = ["10am - 11am", "11am - 12pm", "12pm - 1pm", "1pm - 2pm", "2pm - 3pm", "3pm - 4pm", "4pm - 5pm"]
    let equipmentList: [String] = ["Treadmill", "Rowing machine", "Elliptical machine", "Leg press machine", "Leg extension machine", "Cable crossover machine"]
    
    var timeslotPickerView = UIPickerView()
    var equipmentPickerView = UIPickerView()
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
        }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 1:
            return timeslotList.count
        default:
            return equipmentList.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return timeslotList[row]
        default:
            return equipmentList[row]
        }
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
        case 1:
            timeslotView.text = timeslotList[row]
            timeslotView.resignFirstResponder()
        default:
            equipmentView.text = equipmentList[row]
            equipmentView.resignFirstResponder()
        }
    }

    
    
    
    override func viewWillAppear(_ animated: Bool) {
        instructorImageView.image = UIImage(named: (instructorItem?.instructorImage)!)
        instructorNameView.text = instructorItem?.instructorName
        insctructorDescView.text = instructorItem?.instructorDesc
        
        
    }
    
    
    @IBAction func saveBooking(_ sender: Any) {
        // do some validation to ensure it doesnt return empty
        if DateView.text == "" || timeslotView.text == "" || equipmentView.text == "" {
            
            let alert = UIAlertController(
                title: "Please enter all fields",
                message: "",
                preferredStyle: .alert)
            alert.addAction(UIAlertAction(
                title: "OK",
                style: .default,
                handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        var success: Bool = true
        let bookingList = DataManagerBooking.loadBookings(user_id!)
        if bookingList != [] {
            var count = 1
            for i in bookingList{
                if DateView.text! == i.date && timeslotView.text! == i.timeslot{
                    count = count + 1
                }
                if count > 10{
                    success = false
                    let alert = UIAlertController(
                        title: "This timeslot is fully booked!",
                        message: "capacity of 10 have been reached.",
                        preferredStyle: .alert)
                    alert.addAction(UIAlertAction(
                        title: "OK",
                        style: .default,
                        handler: nil))
                    
                    self.present(alert, animated: true, completion: nil)
                    break // break out of for loop
                }
            }
            
        }
        if success == true{
            
            let bookingObj = BookingSession(user_id!, UUID().uuidString, instructorItem!.instructorName, DateView.text!, timeslotView.text!, equipmentView.text!, addCommentsView.text!)
            
            //Execute SQL to insert data into database
            DataManagerBooking.insertOrReplaceBooking(booking: bookingObj)
            
            
            
            self.navigationController?.popViewController(animated: true)
        }
        

        
    }
    
    var user_id  : String?
    override func viewDidLoad() {
        super.viewDidLoad()
            
        createDatePicker()
        
        timeslotView.inputView = timeslotPickerView
        equipmentView.inputView = equipmentPickerView
        
        timeslotPickerView.delegate = self
        timeslotPickerView.dataSource = self
        equipmentPickerView.delegate = self
        equipmentPickerView.dataSource = self
        
        
        timeslotPickerView.tag = 1
        equipmentView.tag = 2

        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")
        
        
        // Do any additional setup after loading the view.
    }
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


