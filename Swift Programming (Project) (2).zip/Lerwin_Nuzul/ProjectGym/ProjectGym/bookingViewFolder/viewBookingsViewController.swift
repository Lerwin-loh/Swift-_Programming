//
//  viewBookingsViewController.swift
//  ProjectGym
//
//  Created by Training on 23/4/21.
//

import UIKit

class viewBookingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UpdateBookingObj {
    func updateBookingObject() {
        print("running update bookingprotocol function")
        bookingList = DataManagerBooking.loadBookings(user_id!)
        
        self.tableView.reloadData()
    }
    
    
    var user_id: String?
    var bookingList: [BookingSession] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bookingList.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookingCell") as! viewBookingTableViewCell
        
        cell.dateView.text = bookingList[indexPath.row].date
        cell.timeslotView.text = bookingList[indexPath.row].timeslot
        cell.instructorNameView.text = bookingList[indexPath.row].instructorName
        cell.equipmentNameView.text = bookingList[indexPath.row].equipmentName
        cell.addCommentsView.text = bookingList[indexPath.row].addComments
        
        return cell
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete
        {
            let booking = bookingList[indexPath.row]
            DataManagerBooking.deleteBooking(booking: booking)
            bookingList = DataManagerBooking.loadBookings(user_id!)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    
    // This function is triggered when a segue will be triggered.
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?)
    {
        if(segue.identifier == "EditBookingDetails")
        {
            let detailViewController =
                segue.destination as!
            UpdateViewController
            let myIndexPath = self.tableView.indexPathForSelectedRow
            detailViewController.delegate = self
            if(myIndexPath != nil)
            {
                // Set the bookingItem field with the booking object selected by the user.
                let booking = bookingList[myIndexPath!.row]
                detailViewController.bookingItem = booking
                print(booking)
            
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")
        
        bookingList = DataManagerBooking.loadBookings(user_id!)


        
        

        
    }
    


    /*
    // MARK: - Navigation
     
     
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
