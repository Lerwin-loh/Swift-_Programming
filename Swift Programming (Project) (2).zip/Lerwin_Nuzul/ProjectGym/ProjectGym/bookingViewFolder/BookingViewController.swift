//
//  BookingViewController.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

import UIKit

class BookingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var instructorList: [Instructor] = []
    var headerSection: [String] = ["Instructors"]
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headerSection[section]
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return instructorList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "instructorCell") as! instructorTableViewCell
        
        cell.instructorImageView.image = UIImage(named: instructorList[indexPath.row].instructorImage)
        cell.instructorNameView.text = instructorList[indexPath.row].instructorName
        
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DataManagerBooking.createDatabase()
        DataManagerInstructor.createDatabase()
        
        instructorList.append(Instructor("1", "Benjamin Tan", "Benjamin is an instructor that specialises on leg workouts", "face1"))
        instructorList.append(Instructor("2", "Joseph Koh", "Joseph is an instructor that specialises on Body workouts", "face2"))
        instructorList.append(Instructor("3", "Nuzul Yoo", "Nuzul is an instructor that specialises on Shoulder workouts", "face3"))
        instructorList.append(Instructor("4", "Lerwin lee", "Lerwin is an instructor that specialises on hands workouts", "face4"))
        instructorList.append(Instructor("5", "Luke ho", "Luke is an instructor that specialises on thigh workouts", "face5"))
        
        for i in 0 ..< instructorList.count{
            DataManagerInstructor.insertOrReplaceInstructor(instructor: instructorList[i])
        }
        
        
        instructorList = DataManagerInstructor.loadInstructors()
        
        
        

        // Do any additional setup after loading the view.
    }
    

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ShowBookingDetail"{
            let detailViewController = segue.destination as! BookingDetailViewController
            let myIndexPath = self.tableView.indexPathForSelectedRow
            if myIndexPath != nil{
                let instructor = instructorList[myIndexPath!.row]
                detailViewController.instructorItem = instructor
            }
        }
    }

}
