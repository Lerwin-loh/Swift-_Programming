//
//  UpdateViewController.swift
//  ProjectGym
//
//  Created by Lerwin Loh on 25/4/21.
//

import UIKit
protocol UpdateBookingObj{
    func updateBookingObject()
        //replace list with new list
}

class UpdateViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {

    var bookingItem: BookingSession?
    @IBOutlet weak var addCommentsView: UITextField!
    
    

    
    //Date picker configuration
    @IBOutlet weak var dateView: UITextField!

    let datePicker = UIDatePicker()
    
    func createToolBar() -> UIToolbar{
        print("creating tool bar")
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated:true)
        
        return toolbar
    }
    
    func createDatePicker(){
        print("creating date picker")
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.datePickerMode = .date
        dateView.inputView = datePicker
        print("about to create a tool bar")
        dateView.inputAccessoryView = createToolBar()
    }
    
    @objc func donePressed(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        self.dateView.text = dateFormatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    
    //timeslot and equiptment PickerView configuration
    @IBOutlet weak var timeslotView: UITextField!
    
    @IBOutlet weak var equipmentView: UITextField!
    
    let timeslotList = ["10am - 11am", "11am - 12pm", "12pm - 1pm", "1pm - 2pm", "2pm - 3pm", "3pm - 4pm", "4pm - 5pm"]
    let equipmentList: [String] = ["Treadmill", "Rowing machine", "Elliptical machine", "Leg press machine", "Leg extension machine", "Cable crossover machine"]
    
    var timeslotPickerView = UIPickerView()
    var equipmentPickerView = UIPickerView()
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
        }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 1:
            return timeslotList.count
        default:
            return equipmentList.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return timeslotList[row]
        default:
            return equipmentList[row]
        }
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
        case 1:
            timeslotView.text = timeslotList[row]
            timeslotView.resignFirstResponder()
        default:
            equipmentView.text = equipmentList[row]
            equipmentView.resignFirstResponder()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {

        if bookingItem != nil{
            //assign the fields from the booking object to all the text fields on the screen
            dateView.text = bookingItem!.date
            timeslotView.text = bookingItem!.timeslot
            equipmentView.text = bookingItem!.equipmentName
            addCommentsView.text = bookingItem!.addComments
        
        }
        
    }
    
    var delegate: UpdateBookingObj?
    
    @IBAction func savePressed(_ sender: Any) {
        if dateView.text == "" || timeslotView.text == "" || equipmentView.text == "" {
            
            let alert = UIAlertController(title: "Please enter all fields", message: "", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        var success: Bool = true
        let bookingList = DataManagerBooking.loadBookings(user_id!)
        if bookingList != [] {
            var count = 1
            for i in bookingList{
                if dateView.text! == i.date && timeslotView.text! == i.timeslot{
                    count = count + 1
                }
                if count > 10{
                    success = false
                    let alert = UIAlertController(
                        title: "This timeslot is fully booked!",
                        message: "capacity of 10 have been reached.",
                        preferredStyle: .alert)
                    alert.addAction(UIAlertAction(
                        title: "OK",
                        style: .default,
                        handler: nil))
                    
                    self.present(alert, animated: true, completion: nil)
                    break // break out of for loop
                }
            }
            
        }
        if success == true{
            let bookingItemm = BookingSession(bookingItem!.userID ,bookingItem!.bookingID, bookingItem!.instructorName, dateView.text!, timeslotView.text!, equipmentView.text!, addCommentsView.text!)
            
            //Execute SQL to insert data into database
            DataManagerBooking.insertOrReplaceBooking(booking: bookingItemm)
            delegate?.updateBookingObject()
            
            
            self.navigationController?.popViewController(animated: true)

            
        }
        
    }
    
    
    
    var user_id: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        

        let defaults = UserDefaults.standard;
        user_id = defaults.string(forKey: "userID")

        
        
        createDatePicker()
        timeslotView.inputView = timeslotPickerView
        equipmentView.inputView = equipmentPickerView

        
        timeslotPickerView.delegate = self
        timeslotPickerView.dataSource = self
        equipmentPickerView.delegate = self
        equipmentPickerView.dataSource = self
        
        
        timeslotPickerView.tag = 1
        equipmentView.tag = 2
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
