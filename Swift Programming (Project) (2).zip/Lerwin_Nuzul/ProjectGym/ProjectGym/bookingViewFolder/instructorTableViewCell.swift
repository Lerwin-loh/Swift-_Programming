//
//  instructorTableViewCell.swift
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

import UIKit

class instructorTableViewCell: UITableViewCell {

    @IBOutlet weak var instructorImageView: UIImageView!
    @IBOutlet weak var instructorNameView: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
