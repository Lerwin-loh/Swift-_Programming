//
//  LoginViewController.swift
//  GymAppWithSql
//
//  Created by Nuzul FIrdaly on 16/4/21.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var logoImage: UIImageView!
    
    var accountList : [Account] = []
    var accountLoggedin : Account?
        
    @IBAction func loginButtonPressed(_ sender: Any) {
    
    if (validateField() == true){
            //clear the fields
        emailTextField.text = "";
        passwordTextField.text = "";
            //save user id to userdefaults
        let defaults = UserDefaults.standard;
        defaults.set(accountLoggedin!.userID , forKey: "userID") //this is a string

        
            print("move to another view controller please")
        }
//    else{
//            let uiAlert = UIAlertController(title: "Error", message: "Login failed", preferredStyle: .alert)
//            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
//
//            self.present(uiAlert, animated: true, completion: nil)
//    }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logoImage.image = UIImage(named: "logo1")
        passwordTextField.isSecureTextEntry = true
        
        AccountDataManager.CreateDatabase()
        accountList = AccountDataManager.loadAccounts()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        logoImage.image = UIImage(named: "logo1")
        
        AccountDataManager.CreateDatabase()
        accountList = AccountDataManager.loadAccounts()
    }
    
    func validateField () -> Bool {
        
        // check if all fields are filled in
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            print("fields empty")
            let uiAlert = UIAlertController(title: "Error", message: "Please input all fields", preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
            
            self.present(uiAlert, animated: true, completion: nil)
            return false;
        }
        //email validation here
        
        //password validation
        let cleannedEmail = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleannedPassword = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)

        for account in accountList {
            //check email
//            print("checking email")
//            print(account.email, cleannedEmail)
            if account.email == cleannedEmail{
                // check password
//                print("checking password")
//                print(account.password, cleannedPassword)
                if account.password == cleannedPassword{
                    accountLoggedin = account;
                    return true;
                } else{
                    //password does not match
                    let uiAlert = UIAlertController(title: "Error", message: "Password does not match", preferredStyle: .alert)
                    uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
                    
                    self.present(uiAlert, animated: true, completion: nil)
                    return false;
                }
            }
        }
        let uiAlert = UIAlertController(title: "Error", message: "Email does not exist", preferredStyle: .alert)
        uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
        
        self.present(uiAlert, animated: true, completion: nil)
        return false;
        // Check if password is secure
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
