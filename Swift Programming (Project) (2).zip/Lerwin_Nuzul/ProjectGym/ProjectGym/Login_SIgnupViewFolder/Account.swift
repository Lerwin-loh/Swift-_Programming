//
//  Account.swift
//  GymAppWithSql
//
//  Created by Nuzul FIrdaly on 16/4/21.
//

import UIKit

class Account: NSObject {
    var userID: String
    var email: String
    var password: String
    var firstName: String
    var lastName: String
    var bio: String
    var profilePicture: String
        
    init( userID:String, email: String, password: String, firstName: String, lastName: String, bio: String, profilePicture: String){
        
        self.userID = userID
        self.email = email
        self.password = password
        self.firstName = firstName
        self.lastName = lastName
        self.bio = bio
        self.profilePicture = profilePicture
        
    }
}
