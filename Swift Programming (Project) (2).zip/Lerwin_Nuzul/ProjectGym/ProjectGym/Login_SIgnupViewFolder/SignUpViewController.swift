//
//  SignUpViewController.swift
//  GymAppWithSql
//
//  Created by Nuzul FIrdaly on 22/4/21.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    var accountList : [Account] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        passwordTextField.isSecureTextEntry = true
        AccountDataManager.CreateDatabase()
        accountList = AccountDataManager.loadAccounts()
        
        // Do any additional setup after loading the view.
    }
    
    func validateField () -> Bool {
        
        // check if all fields are filled in
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || firstNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || lastNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            print("fields empty")
            let uiAlert = UIAlertController(title: "Error", message: "Please input all fields", preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
            
            self.present(uiAlert, animated: true, completion: nil)
            return false;
        }
        //email validation here
        let cleanedEmail = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if isEmailValid(cleanedEmail) == false {
            print("Email invalid")

            let uiAlert = UIAlertController(title: "Error", message: "Email is not valid", preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
            
            self.present(uiAlert, animated: true, completion: nil)
            
            return false;
        }
        //password validation
        let cleannedPassword = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if isPasswordValid(cleannedPassword) == false {
            print("Password invalid")

            let uiAlert = UIAlertController(title: "Error", message: "Password is not valid", preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
            
            self.present(uiAlert, animated: true, completion: nil)
            
            return false;
        }
        // checking whether email already exist in the database
        print("before for loop")
        print(accountList)
        for accounts in accountList {
            print("entering for loop")
            if emailTextField.text == accounts.email {
                let uiAlert = UIAlertController(title: "Error", message: "Email already exist", preferredStyle: .alert)
                uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: nil))
                self.present(uiAlert, animated: true, completion: nil)

                return false //email already exist in database
            }
            
        }
        return true;
    }
        // Check if password is secure
        
        func isPasswordValid(_ password : String) -> Bool {
            let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
                    return passwordTest.evaluate(with: password)
            
        }
        func isEmailValid(_ email: String) -> Bool{
            
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
            return emailPred.evaluate(with: email)
        }
    @IBAction func signUpButtonPressed(_ sender: Any) {
        
        if (validateField() == true) {
            let account : Account = Account(userID: UUID().uuidString , email: emailTextField.text!, password: passwordTextField.text! , firstName: firstNameTextField.text!, lastName: lastNameTextField.text!, bio: "", profilePicture: "")
            print(account)

            
            //save to database

            AccountDataManager.insertOrReplaceAccount(account: account)
            var viewControllers = self.navigationController?.viewControllers
            let parent = viewControllers?[0] as! LoginViewController
            parent.accountList = AccountDataManager.loadAccounts()

            let uiAlert = UIAlertController(title: "Success", message: "Account has been registered, please log into your account", preferredStyle: .alert)
            uiAlert.addAction(UIAlertAction(title: "Okay", style: .default , handler: { action in
                            self.navigationController?.popViewController(animated: true)
                        }))
            self.present(uiAlert, animated: true, completion: nil)

            
                
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
