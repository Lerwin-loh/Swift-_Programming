//
//  AboutUsViewController.swift
//  ProjectGym
//
//  Created by Training on 26/4/21.
//

import UIKit
import MapKit

class AboutUsViewController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var myMap: MKMapView!
    
    //declare locationManager variable
    let locationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        if (CLLocationManager.locationServicesEnabled()){
            locationManager.requestLocation()
            locationManager.startUpdatingLocation()
        }
        
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // assigning first known location in the array to userLocation
        if let userLocation = locations.first{
            manager.stopUpdatingLocation()
            
            //set coordinate
            // NYP coordinate: 1.3800 'N, 103.8489 'E
            let nypCoordinates = CLLocationCoordinate2D(latitude: 1.3800, longitude: 103.8489)
            
            // set amount of zoom in Apple map
            let span = MKCoordinateSpan (latitudeDelta: 0.04, longitudeDelta: 0.04)
            
            //set region
            let region  = MKCoordinateRegion(center: nypCoordinates, span: span)
            
            //add the region into MKMapView
            myMap.setRegion(region, animated: true)
            
            //set pin on the map
            let nypPin = MKPointAnnotation()
            nypPin.coordinate = nypCoordinates
            nypPin.title = "NYP"
            nypPin.subtitle = "nyp gym"
            
            //add the pin into MKMapView
            myMap.addAnnotation(nypPin)
            
        }
    }
    
    
    //func to request user to capture his location
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager){
        
        switch manager.authorizationStatus{
        case .authorizedAlways:
            return
        case .authorizedWhenInUse:
            return
        case .denied:
            return
        case .restricted:
            locationManager.requestWhenInUseAuthorization()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        default:
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
    //func to check for failure
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
        
    
    

    

}
