//
//  imageEditViewController.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 25/4/21.
//

import UIKit

class imageEditViewController: UIViewController{

    @IBOutlet weak var secondImageView: UIImageView!
    @IBOutlet weak var imageView: UIImageView!
    var accountList : [Account] = []
    var accountLoggedin : Account?
    
    @IBAction func tabButtonPressed(_ sender: Any) {
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard;
        let user_id = defaults.string(forKey: "userID")
        
        AccountDataManager.CreateDatabase()
        accountList = AccountDataManager.loadAccounts()
        
        for accounts in accountList{
            if user_id == accounts.userID{
                accountLoggedin = accounts
            }
        }
        
        

        // Do any additional setup after loading the view.
    }
    

    @IBAction func saveButtonPressed(_ sender: Any) {
        
        //fetching image file and encoding it into base 64 to store it into account db
        let image : UIImage = imageView.image!
        let imageData:NSData = image.pngData()! as NSData
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        print("here is encoded image")
//        print(strBase64)
        // updating account object
        accountLoggedin!.profilePicture = strBase64
        //saving account object to database
        AccountDataManager.insertOrReplaceAccount(account: accountLoggedin!)
        //decoding profile picture data
//        let decodedData = Data(base64Encoded: strBase64, options: .ignoreUnknownCharacters)
//       let dataDecoded:NSData = NSData(base64Encoded: strBase64, options: NSData.Base64DecodingOptions(rawValue: 0))!
//        let decodedimage:UIImage = UIImage(data: decodedData! as Data)!
//        secondImageView.image = decodedimage
        
        _ = navigationController?.popViewController(animated: true)

        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension imageEditViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
            imageView.image = image
        }
        picker.dismiss(animated: true, completion: nil)

    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
