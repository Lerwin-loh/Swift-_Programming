//
//  profileViewController.swift
//  ProjectGym
//
//  Created by Nuzul FIrdaly on 24/4/21.
//

import UIKit

class profileViewController: UIViewController {

    // this label should say Hi, (first name + last name)

    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var bioTextView: UITextView!
    @IBOutlet weak var profilePictureImageView: UIImageView!

    var accountList : [Account] = []
    var accountLoggedin : Account?

    @IBAction func saveButtonPressed(_ sender: Any) {
        
        if firstNameTextField.text == "" ||
            lastNameTextField.text == "" ||
            bioTextView.text == "" ||
            emailTextField.text == ""
        {
            let alert = UIAlertController(
                title: "Please enter all fields",
                message: "",
                preferredStyle: .alert
                
            )
            alert.addAction(
                UIAlertAction(
                    title: "OK",
                    style: .default,
                    handler: nil
            ))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        accountLoggedin!.firstName = firstNameTextField.text!
        accountLoggedin!.lastName = lastNameTextField.text!
        accountLoggedin!.email = emailTextField.text!
        accountLoggedin?.bio = bioTextView.text!
        
        AccountDataManager.insertOrReplaceAccount(account: accountLoggedin!)
        accountList = AccountDataManager.loadAccounts()
        // add alert for saved views
        
        //close this view controller and pop back out
//        self.navigationController?.popViewController(animated: true)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //retrieving userID from localstorage
        let defaults = UserDefaults.standard;
        let user_id = defaults.string(forKey: "userID")
        
        accountList = AccountDataManager.loadAccounts()
        //getting account object using userID
        for accounts in accountList{
            if user_id == accounts.userID{
                accountLoggedin = accounts
            }
        }
        firstNameTextField.text = accountLoggedin!.firstName
        lastNameTextField.text = accountLoggedin!.lastName
        emailTextField.text = accountLoggedin!.email
        self.bioTextView.layer.borderColor = UIColor.lightGray.cgColor
        self.bioTextView.layer.borderWidth = 1
        bioTextView.text = accountLoggedin!.bio
        
        if accountLoggedin!.profilePicture != ""{
            let decodedData = Data(base64Encoded: accountLoggedin!.profilePicture , options: .ignoreUnknownCharacters)
            let decodedimage:UIImage = UIImage(data: decodedData! as Data)!
            profilePictureImageView.image = decodedimage
        }
       
        
    
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard;
        let user_id = defaults.string(forKey: "userID")
        
        AccountDataManager.CreateDatabase()
        accountList = AccountDataManager.loadAccounts()
        //getting account object using userID
        for accounts in accountList{
            if user_id == accounts.userID{
                accountLoggedin = accounts
            }
        }
        firstNameTextField.text = accountLoggedin!.firstName
        lastNameTextField.text = accountLoggedin!.lastName
        emailTextField.text = accountLoggedin!.email
        self.bioTextView.layer.borderColor = UIColor.lightGray.cgColor
        self.bioTextView.layer.borderWidth = 1
        bioTextView.text = accountLoggedin!.bio
        
//        print("here is here")
//        print(accountLoggedin?.profilePicture)
        if accountLoggedin!.profilePicture != ""{
            let decodedData = Data(base64Encoded: accountLoggedin!.profilePicture , options: .ignoreUnknownCharacters)
            let decodedimage:UIImage = UIImage(data: decodedData! as Data)!
            profilePictureImageView.image = decodedimage
        }
        //decoding profile picture data
//        let decodedData = Data(base64Encoded: strBase64, options: .ignoreUnknownCharacters)
//       let dataDecoded:NSData = NSData(base64Encoded: strBase64, options: NSData.Base64DecodingOptions(rawValue: 0))!
//        let decodedimage:UIImage = UIImage(data: decodedData! as Data)!
//        secondImageView.image = decodedimage
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func deleteActionPressed(_ sender: Any) {
        
        let uiAlert = UIAlertController(title: "Confirm Action", message: "Are you sure you'd like to delete your account?", preferredStyle: .alert)
        uiAlert.addAction(UIAlertAction(title: "yes", style: .default , handler: {(action: UIAlertAction!) in
                                            AccountDataManager.deleteAccount(account: self.accountLoggedin!)
                                           self.navigationController?.popViewController(animated: true)

                                             }
            
            
        ))
        uiAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:  nil))

        
        
        self.present(uiAlert, animated: true, completion: nil)
    }
    
}
