//
//  BridgingHeader.m
//  ProjectGym
//
//  Created by Lim Hui Jing on 16/4/21.
//

#import "BridgingHeader.h"

@implementation BridgingHeader

@end
